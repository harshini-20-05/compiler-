#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define NOUN 1
#define VERB 2
#define ADWORD 3
#define PUNCTUATION 4

struct token {
    int type;
    char* value;
};

struct token* createToken(int type, const char* value) {
    struct token* token = (struct token*)malloc(sizeof(struct token));
    token->type = type;
    token->value = strdup(value);
    return token;
}

struct token** lexer(char* str, int* tokensize) {
    int size = 10;
    struct token** tokens = (struct token**)malloc(size * sizeof(struct token*));
    *tokensize = 0;

    int type;
    while (*str != '\0') {
        if (*tokensize >= size) {
            size += 1;
            tokens = (struct token**)realloc(tokens, size * sizeof(struct token*));
        }
        if (isspace(*str)) {
            str++; 
        }
        else if (isalpha(*str) || isdigit(*str)) {
            char* start = str;
            while ((*str >= 'a' && *str <= 'z') || (*str >= 'A' && *str <= 'Z') || (*str >= '0' && *str <= '9')) {
                str++;
            }
            char* check = strndup(start, str - start);
            int count = strlen(check);

            if (check[0] >= 'A' && check[0] <= 'Z') {
                type = NOUN;
                for (int i = 0; i < count; i++) {
                    if (isdigit(check[i])) {
                        type = VERB;
                        break;
                    }
                    else{
                        type=NOUN;
                    }
                }
            } 
            else if (check[0] >= 'a' && check[0] <= 'z') {
                type = ADWORD;
                for (int i = 0; i < count; i++) {
                    if (isdigit(check[i])) {
                        type = VERB;
                        break;
                    }
                }
            } else if(isdigit(check[0])){
                type=VERB;
            }

            tokens[(*tokensize)++] = createToken(type, check);
        } else if (*str == '!' || *str == '?' || *str == '.') {
            type = PUNCTUATION;
            tokens[(*tokensize)++] = createToken(type, str);
        }
        else{
            printf("ERROR\n");
            break;
        }
        str++;
    }

    return tokens;
}
int parse(struct token **tokens,int* length){
    int i=0;
    if(*length>8){
        
        return 0;
    }
    else{
        if(tokens[i]->type==ADWORD ||tokens[i]->type==NOUN){
            if(tokens[i]->type==ADWORD){
                i++;
                if(tokens[i]->type==NOUN){
                    br:
                    i++;
                    if(tokens[i]->type==ADWORD || tokens[i]->type==VERB){
                        if(tokens[i]->type==ADWORD){
                            i++;
                            if(tokens[i]->type==VERB){
                            ex:
                            i++;
                            if(tokens[i]->type==ADWORD || tokens[i]->type==NOUN ||tokens[i]->type==PUNCTUATION ){
                                if(tokens[i]->type==ADWORD){
                                    i++;
                                    if(tokens[i]->type==NOUN ||tokens[i]->type==PUNCTUATION){
                                        if(tokens[i]->type==NOUN){
                                            tr:
                                            i++;
                                            if(tokens[i]->type==ADWORD ||tokens[i]->type==PUNCTUATION ){
                                                if(tokens[i]->type==ADWORD){
                                                    i++;
                                                    if(tokens[i]->type==PUNCTUATION){
                                                        
                                                        sr:
                                                        
                                                        if(i==(*length - 1)){
                                                        return 1;}
                                                        else{
                                                            
                                                            return 0;
                                                        }
                                                    }
                                                    else{
                                                        
                                                        return 0;
                                                    }
                                                }
                                                else{
                                                    if(i==(*length- 1)){
                                                        return 1;
                                                    }
                                                    else{
                                                        
                                                        return 0;
                                                    }
                                                }
                                            }
                                            else{
                                                return 0;
                                            }
                                        }
                                    }
                                    else{
                                        return 0;
                                    }
                                }
                                else if(tokens[i]->type==NOUN){
                                    goto tr;
                                }
                                else{
                                    goto sr;
                                }
                            }
                            else{
                                return 0;
                            }
                            }
                            else{
                                return 0;
                            }
                        }
                        else{
                            goto ex;
                        }
                    }
                    else{
                        return 0;
                    }
                }
                else{
                    return 0;
                }
            }
            else{
                goto br;
            }
        }
        else{
            return 0;
        }
    }
}
struct TreeNode {
    int data;
    char* value;
    struct TreeNode* left;
    struct TreeNode* right;
};
struct TreeNode* createTreeNode(int data,char* value) {
    struct TreeNode* newNode = (struct TreeNode*)malloc(sizeof(struct TreeNode));
    if (newNode == NULL) {
        perror("Failed to allocate memory for tree node");
        exit(EXIT_FAILURE);
    }
    newNode->data = data;
    newNode->value=value;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}
struct TreeNode* ast(struct token** tokens,int *length){
    struct TreeNode* header=(struct TreeNode*)malloc(sizeof(struct TreeNode));
    struct TreeNode* ptr=(struct TreeNode*)malloc(sizeof(struct TreeNode));
    header=createTreeNode(tokens[0]->type,tokens[0]->value);
    ptr=header;
    for(int i=1;i<*length;i++){
        ptr->left=createTreeNode(tokens[i]->type,tokens[i]->value);
        ptr=ptr->left;
    }
    return header;
}
int main() {
    char code[100];
    fgets(code, sizeof(code), stdin);
    int tokensize;
    struct token** tokens = lexer(code, &tokensize);
    for (int i = 0; i < tokensize; i++) {
        struct token* token = tokens[i];
        printf("Token Type: %d, Value: %s\n", token->type, token->value);
        
    }
    int z=parse(tokens,&tokensize);
    struct TreeNode* header=(struct TreeNode*)malloc(sizeof(struct TreeNode));
    struct TreeNode* ptr=(struct TreeNode*)malloc(sizeof(struct TreeNode));
    if(z==1){
        header=ast(tokens,&tokensize);
    }
    ptr=header;
    for(int i=0;i<(tokensize- 1);i++){
        printf("(%d-%s) ->",ptr->data,ptr->value);
        ptr=ptr->left;
    }
    printf("(%d-%s)\n",ptr->data,ptr->value);
    return 0;
}
